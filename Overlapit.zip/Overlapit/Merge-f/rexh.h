#include <regex.h>
#include <cstring>
using namespace std;

int email_is_valid(char [256]);
