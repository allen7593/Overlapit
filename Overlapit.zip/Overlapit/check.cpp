#include <fstream>
#include <cstdlib>

using namespace std;
int main()
{
	ifstream fileIn("/home/allen7593/Overlapit/on");
	if(fileIn.is_open())
		system("~/Overlapit/mainWindow");
	return 0;
}
